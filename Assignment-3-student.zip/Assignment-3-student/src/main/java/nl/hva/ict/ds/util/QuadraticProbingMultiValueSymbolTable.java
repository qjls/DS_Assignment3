package nl.hva.ict.ds.util;

import nl.hva.ict.ds.Player;

import java.util.List;

public class QuadraticProbingMultiValueSymbolTable implements MultiValueSymbolTable<String, Player> {
    public QuadraticProbingMultiValueSymbolTable(int arraySize) {
    }

    @Override
    public void put(String key, Player value) {

    }

    @Override
    public List<Player> get(String key) {
        return null;
    }
}
